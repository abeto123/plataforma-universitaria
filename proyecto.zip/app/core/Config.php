<?php

define('APPROOT', dirname(dirname(__FILE__)));
define('APP_NAME', 'PLATAFORMA UNIVERSITARIA');
define('BASE_URL', 'http://localhost/plataforma-universitaria/');

session_start();

?>